<?php 

define("PATH_TMP" , "include/") ;
define("PATH_CSS" , "layout/css/") 		; 
define("PATH_IMG" , "layout/images/") 		; 
define("PATH_JS"  , "layout/js/") 		; 

?>