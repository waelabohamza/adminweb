<div class="row">

    <div class="image_admin col-md-12">

        <img src="../../<?php echo  PATH_IMG ?>avatar.png  " class="img-responsive center-block" />

    </div>

</div>

<div class="clearfix"></div>

<div class="row">

    <ul class="list-unstyled listside">
        <a href="../home/home.php">
            <li>

                <span>
                    <i class="fa fa-home fa-lg"> </i>
                </span>

                HomePage

            </li>
        </a>
        <a href="../users/users.php">
            <li>
                <span>
                    <i class="fa fa-users fa-lg"> </i>
                </span>

                Users

            </li>
        </a>
        <a href="../categories/categories.php">
            <li>
                <span>
                    <i class="fa fa-list-alt fa-lg"> </i>
                </span>

                Categories

            </li>
        </a>
        <a href="../services/services.php">
            <li>
                <span>
                    <i class="fa fa-suitcase fa-lg"> </i>
                </span>

                Services

            </li>
        </a>
        <a href="../catcourses/catcourses.php">
            <li>
                <span>
                    <i class="fa fa-list-alt fa-lg"> </i>
                </span>

                Catergories Course

            </li>
        </a>
        <a href="../courses/courses.php">
            <li>
                <span>
                    <i class="fa fa-address-book fa-lg"> </i>
                </span>

                courses

            </li>
        </a>
        <a href="../catexperts/catexperts.php">
            <li>
                <span>
                    <i class="fa fa-list-alt fa-lg"> </i>
                </span>

                categories Experts

            </li>
        </a>
        <a href="../experts/experts.php">
            <li>
                <span>
                    <i class="fa fa-address-card-o fa-lg"> </i>
                </span>

                Experts

            </li>
        </a>
        <a href="../questions/questions.php">
            <li>
                <span>
                    <i class="fa fa-question-circle fa-lg"> </i>
                </span>

                Questions

            </li>
        </a>
        <a href="../orderscourses/orderscourses.php">
            <li>
                <span>
                    <i class="fa fa-inbox fa-lg"> </i>
                </span>

                Orders Course

            </li>
        </a>
        <a href="../ordersservices/ordersservices.php">
            <li>
                <span>
                    <i class="fa fa-inbox fa-lg"> </i>
                </span>

                Orders Service

            </li>
        </a>
        <a href="../../logout.php">
            
            <li>

                <span>
                    <i class="fa fa-sign-out fa-lg"> </i>
                </span>

                Logout

            </li>
        </a>

    </ul>


</div>