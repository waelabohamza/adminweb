<div class="row">

    <div class="image_admin col-md-12">

        <img src="../../<?php echo  PATH_IMG ?>avatar.png  " class="img-responsive center-block" />
  
    </div>

</div>

<div class="clearfix"></div>

<div class="row">

    <ul class="list-unstyled listside">
    <a href="../home/home.php">
        <li>

            <span>
                <i class="fa fa-home fa-lg"> </i>
            </span>

            HomePage

        </li>
    </a>
        <a href="">
        <li>
            <span>
                <i class="fa fa-users fa-lg"> </i>
            </span>

            Users

        </li>
        </a>
        <a href="../categories/categories.php">
        <li>
            <span>
                <i class="fa fa-list-alt fa-lg"> </i>
            </span>

            Categories

        </li>
        </a>
        <a href="">
        <li>
            <span>
                <i class="fa fa-suitcase fa-lg"> </i>
            </span>

            Services

        </li>
        </a>
        <a href="">
        <li>

            <span>
                <i class="fa fa-sign-out fa-lg"> </i>
            </span>

            Logout

        </li>
        </a>

    </ul>


</div>