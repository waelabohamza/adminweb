 <!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin Wael Abo Hamza</title>

    <link href="../../<?php echo PATH_CSS  ?>bootstrap.css" rel="stylesheet">
    <link href="../../<?php echo PATH_CSS ?>font-awesome.min.css" rel="stylesheet">
    <link href="../../<?php echo PATH_CSS ?>nice-select.css" rel="stylesheet">
    <link href="../../<?php echo PATH_CSS ?>style.css" rel="stylesheet">

   
    <script src="../../<?php echo PATH_JS ?>jquery-1.12.1.min.js"></script>
    <script src="../../<?php echo PATH_JS ?>jquery.nice-select.min.js"></script>
    <script src="../../<?php echo PATH_JS ?>bootstrap.js"></script>
    <script src="../../<?php echo PATH_JS ?>style.js"></script>

  </head>

  <body>